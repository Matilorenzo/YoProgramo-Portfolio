package com.portfolio.MLG;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MlgApplication {

	public static void main(String[] args) {
		SpringApplication.run(MlgApplication.class, args);
	}

}
