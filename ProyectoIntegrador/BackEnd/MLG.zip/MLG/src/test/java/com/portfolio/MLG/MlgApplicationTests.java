package com.portfolio.MLG;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MlgApplicationTests {

	@Test
	void contextLoads() {
	}

}
